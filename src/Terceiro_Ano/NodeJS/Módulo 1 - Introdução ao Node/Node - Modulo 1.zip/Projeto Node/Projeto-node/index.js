console.log("Bem-vindo ao Node.js!");
