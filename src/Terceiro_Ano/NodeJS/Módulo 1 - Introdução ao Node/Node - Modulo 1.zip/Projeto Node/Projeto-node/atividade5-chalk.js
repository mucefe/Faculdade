const chalk = require('chalk');

console.log(chalk.red('Erro: Falha ao conectar ao servidor.'));
